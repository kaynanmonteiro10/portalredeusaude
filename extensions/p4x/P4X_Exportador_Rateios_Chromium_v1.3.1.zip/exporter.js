(async () => {
  if (window.__P4X_RATEIOS_EXPORT_RUNNING__) {
    alert("A exportação já está em andamento.");
    return;
  }
  window.__P4X_RATEIOS_EXPORT_RUNNING__ = true;
  // Enquanto o exportador faz as próprias chamadas, a ponte da página não
  // deve tratá-las como "a pesquisa do usuário".
  window.__P4X_RATEIOS_INTERNAL__ = true;

  const API_ROOT = "https://api.p4x.com.br/extratos/rateios/recebidos";
  const PAGE_SIZE_FALLBACK = 200;
  const MAX_PAGES = 500;
  const MAX_AUTO_UPLOAD = 20000000;
  const upload = document.documentElement.dataset.p4xUpload === "1";
  document.documentElement.dataset.p4xUpload = "";

  const PAGE_KEYS = ["paginaatual", "pagina", "page", "numeropagina", "paginaconsultada"];
  const SIZE_KEYS = ["totalporpagina", "tamanhopagina", "tamanho", "size", "pagesize", "limite", "limiteporpagina", "quantidadeporpagina"];
  const LIST_KEYS = ["listaItens", "lista", "itens", "items", "content", "dados", "registros", "resultado", "resultados", "rows", "records"];
  const TOTAL_KEYS = ["totalRegistros", "total", "totalElements", "totalItens", "quantidadeTotal"];
  const PAGES_KEYS = ["totalPaginas", "totalPages", "paginas", "quantidadePaginas"];

  let token = "";
  let base = null;
  let paging = null;

  function notify(message, detail) {
    let el = document.getElementById("p4x-rateios-status");
    if (!el) {
      el = document.createElement("div");
      el.id = "p4x-rateios-status";
      el.style.cssText = "position:fixed;z-index:2147483647;right:20px;bottom:20px;background:#173f2b;color:#fff;padding:16px 20px;border-radius:9px;font:14px Arial;box-shadow:0 4px 20px #0004;max-width:min(560px,92vw);white-space:pre-line;line-height:1.5;overflow-wrap:anywhere;user-select:text";
      document.body.appendChild(el);
    }
    el.textContent = detail ? `${message}\n${detail}` : message;
  }

  function dispatchReady(base64, rows, pairs) {
    const holder = document.createElement("div");
    holder.id = "p4x-rateios-payload";
    holder.style.display = "none";
    holder.textContent = base64;
    holder.dataset.rows = String(rows);
    holder.dataset.pairs = String(pairs);
    document.body.appendChild(holder);
    window.dispatchEvent(new Event("p4x-rateios-ready"));
  }

  function dispatchError(message) {
    const holder = document.createElement("div");
    holder.id = "p4x-rateios-error";
    holder.style.display = "none";
    holder.textContent = message;
    document.body.appendChild(holder);
    window.dispatchEvent(new Event("p4x-rateios-error"));
  }

  function loadXLSX() {
    return new Promise((resolve, reject) => {
      if (window.XLSX) return resolve(window.XLSX);
      const script = document.createElement("script");
      script.src = "https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js";
      script.onload = () => window.XLSX ? resolve(window.XLSX) : reject(new Error("Biblioteca Excel indisponível."));
      script.onerror = () => reject(new Error("Não foi possível carregar o componente Excel. Verifique a conexão ou as regras de segurança do portal."));
      document.head.appendChild(script);
    });
  }

  function uniqueSheetName(name, used) {
    let base = String(name || "Rateio").replace(/\.TXT$/i, "").replace(/[\\/?*[\]:]/g, "").trim().slice(0, 31) || "Rateio";
    let finalName = base, n = 2;
    while (used.has(finalName.toLowerCase())) {
      const suffix = ` (${n++})`;
      finalName = base.slice(0, 31 - suffix.length) + suffix;
    }
    used.add(finalName.toLowerCase());
    return finalName;
  }

  function excelDate(value) {
    if (typeof value === "number") return value;
    if (value instanceof Date && !isNaN(value)) {
      return Date.UTC(value.getFullYear(), value.getMonth(), value.getDate()) / 86400000 + 25569;
    }
    if (typeof value !== "string" || !value.trim()) return null;
    const s = value.trim();
    let m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
    let d, mo, y;
    if (m) { d = +m[1]; mo = +m[2]; y = +m[3]; }
    else {
      m = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
      if (!m) return null;
      y = +m[1]; mo = +m[2]; d = +m[3];
    }
    const date = new Date(Date.UTC(y, mo - 1, d));
    if (date.getUTCFullYear() !== y || date.getUTCMonth() !== mo - 1 || date.getUTCDate() !== d) return null;
    return date.getTime() / 86400000 + 25569;
  }

  function formatDates(XLSX, sheet) {
    if (!sheet["!ref"]) return;
    const range = XLSX.utils.decode_range(sheet["!ref"]);
    for (let r = 3; r <= range.e.r; r++) {
      for (const c of [10, 11, 12, 13]) {
        const addr = XLSX.utils.encode_cell({ r, c });
        const cell = sheet[addr];
        if (!cell || cell.v === "" || cell.v == null) continue;
        const converted = excelDate(cell.v);
        if (converted !== null) {
          cell.v = converted;
          cell.t = "n";
          cell.z = "dd/mm/yyyy";
        }
      }
    }
  }

  function receiverColumns(XLSX, sheet, receiverName, receiverDoc) {
    if (!sheet["!ref"]) return;
    const range = XLSX.utils.decode_range(sheet["!ref"]);
    const nameColumn = Math.max(14, range.e.c + 1);
    const docColumn = nameColumn + 1;
    const put = (row, column, value) => {
      const address = XLSX.utils.encode_cell({ r: row, c: column });
      sheet[address] = { t: "s", v: String(value || "") };
    };
    put(2, nameColumn, "Recebedor");
    put(2, docColumn, "CPF/CNPJ do recebedor");
    for (let row = 3; row <= range.e.r; row++) {
      put(row, nameColumn, receiverName);
      put(row, docColumn, receiverDoc);
    }
    range.e.c = Math.max(range.e.c, docColumn);
    sheet["!ref"] = XLSX.utils.encode_range(range);
  }

  function lower(value) {
    return String(value).toLowerCase();
  }

  // A pesquisa do P4X pode vir por GET (filtros na URL) ou por POST
  // (filtros no corpo). O corpo é preservado para ser reenviado página a página.
  function parseBody(text, contentType) {
    const trimmed = String(text || "").trim();
    if (!trimmed) return null;
    if (/json/i.test(contentType) || /^[\[{]/.test(trimmed)) {
      try { return { kind: "json", value: JSON.parse(trimmed) }; } catch (_) {}
    }
    if (/x-www-form-urlencoded/i.test(contentType) || /^[^=&\s]+=[^&]*/.test(trimmed)) {
      try { return { kind: "form", value: new URLSearchParams(trimmed) }; } catch (_) {}
    }
    return null;
  }

  function readBaseRequest() {
    const captured = window.__P4X_RATEIOS_LIST_REQUEST__;
    const url = (captured && captured.url) || window.__P4X_RATEIOS_LIST_URL__ || "";
    if (!url) return null;
    return {
      url: String(url),
      method: (captured && captured.method) || "GET",
      contentType: (captured && captured.contentType) || "",
      body: captured && captured.body ? parseBody(captured.body, captured.contentType) : null
    };
  }

  function findPaging(request) {
    const url = new URL(request.url);
    let pageKey = "", pageIn = "", pageValue = null;
    let sizeKey = "", sizeIn = "", sizeValue = null;
    for (const key of Array.from(url.searchParams.keys())) {
      if (!pageKey && PAGE_KEYS.includes(lower(key))) {
        pageKey = key; pageIn = "url"; pageValue = url.searchParams.get(key);
      }
      if (!sizeKey && SIZE_KEYS.includes(lower(key))) {
        sizeKey = key; sizeIn = "url"; sizeValue = url.searchParams.get(key);
      }
    }
    const body = request.body;
    if (body && body.kind === "json" && body.value && typeof body.value === "object" && !Array.isArray(body.value)) {
      for (const key of Object.keys(body.value)) {
        const value = body.value[key];
        if (value && typeof value === "object") continue;
        if (!pageKey && PAGE_KEYS.includes(lower(key))) { pageKey = key; pageIn = "body"; pageValue = value; }
        if (!sizeKey && SIZE_KEYS.includes(lower(key))) { sizeKey = key; sizeIn = "body"; sizeValue = value; }
      }
    }
    if (body && body.kind === "form") {
      for (const [key, value] of body.value.entries()) {
        if (!pageKey && PAGE_KEYS.includes(lower(key))) { pageKey = key; pageIn = "form"; pageValue = value; }
        if (!sizeKey && SIZE_KEYS.includes(lower(key))) { sizeKey = key; sizeIn = "form"; sizeValue = value; }
      }
    }
    const parsedSize = Number(sizeValue);
    const size = Number.isFinite(parsedSize) && parsedSize > 0 ? parsedSize : PAGE_SIZE_FALLBACK;
    return {
      pageKey: pageKey || "paginaAtual",
      pageIn: pageIn || "url",
      sizeKey: sizeKey || "totalPorPagina",
      sizeIn: sizeIn || "url",
      // Sempre começamos na PRIMEIRA página da pesquisa (0 ou 1),
      // mesmo que o usuário tenha navegado para outra antes de exportar.
      baseIndex: Number(pageValue) === 0 ? 0 : 1,
      size
    };
  }

  function buildRequest(index) {
    const url = new URL(base.url);
    const setPaging = (key, where, value) => {
      if (where === "body" && base.body && base.body.kind === "json") {
        base.body.value[key] = value;
      } else if (where === "form" && base.body && base.body.kind === "form") {
        base.body.value.set(key, String(value));
      } else {
        url.searchParams.set(key, String(value));
      }
    };
    setPaging(paging.pageKey, paging.pageIn, index);
    setPaging(paging.sizeKey, paging.sizeIn, paging.size);
    const headers = { "Accept": "application/json", "Authorization": `Bearer ${token}` };
    if (base.contentType) headers["Content-Type"] = base.contentType;
    let bodyText = null;
    if (base.body) {
      bodyText = base.body.kind === "json" ? JSON.stringify(base.body.value) : base.body.value.toString();
    }
    const init = { method: base.method || "GET", headers, credentials: "include" };
    if (init.method !== "GET" && bodyText !== null) init.body = bodyText;
    return { url: url.toString(), init };
  }

  async function fetchPage(index, label) {
    const request = buildRequest(index);
    const response = await fetch(request.url, request.init);
    if (response.status === 401 || response.status === 403) {
      throw new Error("O P4X recusou a autenticação. Atualize o portal e tente novamente.");
    }
    if (!response.ok) throw new Error(`${label} falhou (HTTP ${response.status}).`);
    const data = await response.json().catch(() => null);
    if (!data) throw new Error(`${label} não retornou dados válidos.`);
    return data;
  }

  function listItems(data) {
    if (Array.isArray(data)) return data;
    if (!data || typeof data !== "object") return [];
    for (const key of LIST_KEYS) {
      if (Array.isArray(data[key])) return data[key];
    }
    for (const value of Object.values(data)) {
      if (!value || typeof value !== "object" || Array.isArray(value)) continue;
      for (const key of LIST_KEYS) {
        if (Array.isArray(value[key])) return value[key];
      }
    }
    for (const value of Object.values(data)) {
      if (Array.isArray(value) && value.length && typeof value[0] === "object") return value;
    }
    return [];
  }

  function numberFrom(data, keys) {
    if (!data || typeof data !== "object") return 0;
    const read = object => {
      if (!object || typeof object !== "object" || Array.isArray(object)) return null;
      for (const key of Object.keys(object)) {
        if (!keys.some(name => lower(name) === lower(key))) continue;
        const number = Number(object[key]);
        if (object[key] !== "" && object[key] !== null && Number.isFinite(number)) return number;
      }
      return null;
    };
    const direct = read(data);
    if (direct !== null) return direct;
    for (const value of Object.values(data)) {
      const nested = read(value);
      if (nested !== null) return nested;
    }
    return 0;
  }

  function pick(objects, keys) {
    for (const object of objects) {
      if (!object || typeof object !== "object") continue;
      for (const key of Object.keys(object)) {
        if (!keys.includes(lower(key))) continue;
        const value = object[key];
        if (value !== undefined && value !== null && value !== "") return value;
      }
    }
    return null;
  }

  function asId(value) {
    if (value === null || value === undefined) return "";
    if (typeof value === "object") {
      return asId(value.id ?? value.codigo ?? value.uuid ?? value.key ?? value.chave ?? value.value ?? value.valor);
    }
    return String(value).trim();
  }

  function collectPairs(items) {
    const pairs = [];
    const seen = new Set();
    for (const item of items || []) {
      if (!item || typeof item !== "object") continue;
      const fileObject = item.arquivo || item.arquivoOrigem || item.arquivoPagamento
        || item.documento || item.arquivoFinanceiro || item.arquivoProcessado || null;
      const receiverObject = item.sacadorRecebedor || item.recebedor || item.pessoaRecebedora
        || item.sacador || item.beneficiario || item.favorecido || null;
      const fileId = asId(
        pick([fileObject], ["id", "codigo", "uuid", "key", "chave"])
        || pick([item], ["arquivoid", "idarquivo", "codigoarquivo", "idarquivoorigem", "arquivoidorigem"])
      );
      const receiverId = asId(
        pick([receiverObject], ["id", "codigo", "uuid", "key", "chave"])
        || pick([item], ["sacadorrecebedorid", "idsacadorrecebedor", "recebedorid", "idrecebedor", "idpessoa", "pessoaid"])
      );
      if (!fileId || !receiverId) continue;
      const key = `${fileId}::${receiverId}`;
      if (seen.has(key)) continue;
      seen.add(key);
      pairs.push({
        fileId,
        receiverId,
        fileLabel: String(pick([fileObject], ["nome", "nomearquivo", "descricao", "filename", "name"]) || pick([item], ["nomearquivo", "arquivonome"]) || ""),
        receiverName: String(pick([receiverObject], ["razaosocial", "nomefantasia", "nome", "nomecompleto", "descricao"]) || pick([item], ["razaosocial", "nomefantasia"]) || ""),
        receiverDoc: String(pick([receiverObject], ["cpfcnpj", "documento", "cnpj", "cpf", "nrdocumento", "numerodocumento"]) || pick([item], ["cpfcnpj"]) || "")
      });
    }
    return pairs;
  }

  function shapeOf(response, items, totalRecords, totalPages) {
    const keys = response && typeof response === "object" && !Array.isArray(response) ? Object.keys(response).slice(0, 12) : [];
    let sample = "";
    try { sample = items[0] ? JSON.stringify(items[0]) : ""; } catch (_) {}
    if (sample.length > 480) sample = `${sample.slice(0, 480)}…`;
    const lines = [
      `itens=${items.length} · totalRegistros=${totalRecords} · totalPaginas=${totalPages}`,
      `chaves=[${keys.join(", ")}]`,
      `paginação: ${paging.pageKey}=${paging.baseIndex} (${paging.baseIndex === 0 ? "base 0" : "base 1"}), ${paging.sizeKey}=${paging.size}`
    ];
    if (sample) lines.push(`1º item: ${sample}`);
    return lines.join("\n");
  }

  // A lista vem da própria pesquisa do P4X. Se refazer a chamada não devolver
  // os itens (filtro, cabeçalhos ou paginação diferentes), usamos a resposta
  // que a tela já carregou, capturada pela ponte da página.
  async function loadItems() {
    const captured = window.__P4X_RATEIOS_LIST_RESPONSE__ || null;
    const capturedItems = listItems(captured || {});
    const capturedTotal = numberFrom(captured || {}, TOTAL_KEYS) || capturedItems.length;
    let response = null;
    let items = [];
    let totalRecords = 0;
    let totalPages = 1;
    let source = "api";

    try {
      response = await fetchPage(paging.baseIndex, "Leitura da lista");
      items = listItems(response);
      totalRecords = numberFrom(response, TOTAL_KEYS) || items.length;
      totalPages = numberFrom(response, PAGES_KEYS) || 1;

      // Se o P4X usa páginas começando em zero, a página "1" pode vir vazia.
      if (!items.length && totalRecords > 0 && paging.baseIndex !== 0) {
        const zeroPage = await fetchPage(0, "Leitura da lista");
        const zeroItems = listItems(zeroPage);
        if (zeroItems.length) {
          paging.baseIndex = 0;
          response = zeroPage;
          items = zeroItems;
          totalRecords = numberFrom(zeroPage, TOTAL_KEYS) || totalRecords;
          totalPages = numberFrom(zeroPage, PAGES_KEYS) || totalPages;
        }
      }
    } catch (error) {
      if (!capturedItems.length) throw error;
      response = captured;
      items = capturedItems.slice();
      totalRecords = capturedTotal;
      totalPages = numberFrom(captured || {}, PAGES_KEYS) || 1;
      source = "tela";
    }

    if (!items.length && capturedItems.length) {
      response = captured;
      items = capturedItems.slice();
      totalRecords = capturedTotal;
      totalPages = numberFrom(captured || {}, PAGES_KEYS) || 1;
      source = "tela";
    }

    if (totalPages > MAX_PAGES) {
      throw new Error(`A lista passou de ${MAX_PAGES} páginas. Refine o filtro no P4X e tente novamente.`);
    }

    if (totalPages > 1 && items.length < (totalRecords || items.length)) {
      if (source === "tela") {
        throw new Error(
          "O P4X mostrou apenas parte do resultado e não consegui ler as outras páginas.\n" +
          "No P4X, aumente a quantidade de registros por página (ex.: 200) e clique em Pesquisar. Depois importe novamente."
        );
      }
      for (let page = 2; page <= totalPages; page++) {
        notify("Lendo a lista do filtro...", `Página ${page} de ${totalPages} · ${items.length} de ${totalRecords} registros`);
        const data = await fetchPage(paging.baseIndex + (page - 1), `Leitura da página ${page}`);
        const pageItems = listItems(data);
        if (!pageItems.length) break;
        items.push(...pageItems);
      }
    }

    return { response, items, totalRecords, totalPages, source };
  }

  try {
    notify("Verificando sua sessão no P4X...");
    token = window.__P4X_RATEIOS_AUTH__ || "";
    if (!token) {
      throw new Error("Não consegui identificar a sessão. Atualize o portal P4X, aguarde a tela carregar e tente novamente.");
    }
    base = readBaseRequest();
    if (!base) {
      throw new Error(
        "Não consegui identificar o filtro aplicado.\n" +
        "No P4X, abra Extratos → Rateios recebidos, aplique o filtro e clique em Pesquisar. Depois use a extensão novamente."
      );
    }

    paging = findPaging(base);
    notify("Lendo a lista de rateios do filtro...");
    const listed = await loadItems();
    const response = listed.response;
    const items = listed.items;
    const totalRecords = listed.totalRecords;
    const totalPages = listed.totalPages;

    const pairs = collectPairs(items);
    if (!pairs.length) {
      throw new Error(
        `O filtro não retornou rateios com arquivo e recebedor.\n${shapeOf(response, items, totalRecords, totalPages)}`
      );
    }

    notify("Preparando o Excel...");
    const XLSX = await loadXLSX();
    const finalBook = XLSX.utils.book_new();
    const usedNames = new Set();
    let totalRows = 0;

    for (let index = 0; index < pairs.length; index++) {
      const pair = pairs[index];
      notify(
        "Baixando rateios...",
        `${index + 1} de ${pairs.length} · ${pair.fileLabel || pair.fileId}`
      );
      const download = await fetch(`${API_ROOT}/${encodeURIComponent(pair.fileId)}/${encodeURIComponent(pair.receiverId)}/?exportar=true`, {
        method: "GET",
        headers: { "Authorization": `Bearer ${token}`, "Accept": "*/*" },
        credentials: "include"
      });

      if (download.status === 401 || download.status === 403) {
        throw new Error("O P4X recusou a autenticação. Atualize o portal e tente novamente.");
      }
      if (!download.ok) throw new Error(`Falha no rateio ${index + 1} de ${pairs.length} (HTTP ${download.status}).`);

      const buffer = await download.arrayBuffer();
      const bytes = new Uint8Array(buffer);
      if (bytes.length < 2 || bytes[0] !== 0x50 || bytes[1] !== 0x4B) {
        throw new Error(`O rateio ${index + 1} não retornou um arquivo Excel válido.`);
      }

      const sourceBook = XLSX.read(buffer, { type: "array", cellDates: false });
      const sourceName = sourceBook.SheetNames[0];
      if (!sourceName) throw new Error(`O rateio ${index + 1} veio sem planilha.`);

      const sheet = sourceBook.Sheets[sourceName];
      const rows = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: "", raw: true });
      const fileLabel = String(rows[1]?.[0] || "").replace(/^Arquivo:\s*/i, "").trim();
      const sheetName = uniqueSheetName(fileLabel || `Rateio ${index + 1}`, usedNames);

      receiverColumns(XLSX, sheet, pair.receiverName, pair.receiverDoc);
      formatDates(XLSX, sheet);

      totalRows += rows.slice(3).filter(row => row.some((value, column) => column < 14 && value !== "" && value != null)).length;
      XLSX.utils.book_append_sheet(finalBook, sheet, sheetName);
    }

    if (finalBook.SheetNames.length !== pairs.length) {
      throw new Error("Nem todos os rateios foram processados. O arquivo não será gerado.");
    }

    if (upload) {
      notify("Preparando o envio ao portal...");
      const base64 = XLSX.write(finalBook, {
        bookType: "xlsx",
        type: "base64",
        compression: true
      });
      if (!base64 || base64.length > MAX_AUTO_UPLOAD) {
        XLSX.writeFile(finalBook, "Rateios_Recebidos_Consolidado.xlsx", {
          bookType: "xlsx",
          compression: true
        });
        throw new Error("O arquivo ficou grande para envio automático. Baixei o Excel; importe pelo botão “Enviar arquivo .xlsx”.");
      }
      notify("Enviando os rateios para o portal...", `${pairs.length} rateio(s) · ${totalRows} registro(s)`);
      dispatchReady(base64, totalRows, pairs.length);
    } else {
      notify("Finalizando arquivo Excel...");
      XLSX.writeFile(finalBook, "Rateios_Recebidos_Consolidado.xlsx", {
        bookType: "xlsx",
        compression: true
      });
      notify(
        "Concluído!",
        `${pairs.length} rateio(s) do filtro · ${totalRows} registro(s).\nO download foi iniciado. Importe o arquivo na tela Financeiro do portal.`
      );
    }
    setTimeout(() => {
      const el = document.getElementById("p4x-rateios-status");
      if (el) el.remove();
    }, upload ? 30000 : 12000);
  } catch (error) {
    console.error("[P4X Exportador]", error);
    notify(`Não foi possível concluir.\n${error.message}`);
    if (upload) dispatchError(error.message);
    else alert(`Exportação não concluída:\n\n${error.message}`);
  } finally {
    window.__P4X_RATEIOS_EXPORT_RUNNING__ = false;
    window.__P4X_RATEIOS_INTERNAL__ = false;
  }
})();
