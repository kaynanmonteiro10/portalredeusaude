const ext = globalThis.browser || globalThis.chrome;

document.getElementById("exportar").addEventListener("click", async () => {
  const status = document.getElementById("status");
  const botao = document.getElementById("exportar");
  botao.disabled = true;
  status.textContent = "Solicitando exportação ao P4X...";
  try {
    const [tab] = await ext.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.url || !tab.url.startsWith("https://portal.p4x.com.br/")) {
      throw new Error("Abra o portal P4X antes de iniciar a exportação.");
    }
    await ext.tabs.sendMessage(tab.id, { action: "EXPORTAR_RATEIOS" });
    status.textContent = "Exportação iniciada. A extensão percorre todas as páginas do filtro e baixa um consolidado. Acompanhe o aviso na página do P4X.";
  } catch (e) {
    status.textContent = e.message || "Não foi possível iniciar. Atualize a página do P4X e tente novamente.";
  } finally {
    botao.disabled = false;
  }
});