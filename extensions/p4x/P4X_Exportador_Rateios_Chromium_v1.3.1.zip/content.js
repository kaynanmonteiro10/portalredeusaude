(() => {
  const ext = globalThis.browser || globalThis.chrome;

  function inject(file, upload) {
    document.documentElement.dataset.p4xUpload = upload ? "1" : "";
    const s = document.createElement("script");
    s.src = ext.runtime.getURL(file);
    s.onload = () => s.remove();
    (document.documentElement || document.head).appendChild(s);
  }

  function payloadText(id) {
    const element = document.getElementById(id);
    if (!element) return "";
    const value = element.textContent || "";
    element.remove();
    return value;
  }

  function showStatus(message) {
    const element = document.getElementById("p4x-rateios-status");
    if (element) element.textContent = message;
  }

  // Captura o cabeçalho Authorization das chamadas que o próprio portal faz.
  // O token permanece apenas na página/sessão; não é enviado a terceiros.
  inject("page-bridge.js", false);

  window.addEventListener("p4x-rateios-ready", () => {
    const holder = document.getElementById("p4x-rateios-payload");
    const rows = holder ? Number(holder.dataset.rows) || 0 : 0;
    const pairs = holder ? Number(holder.dataset.pairs) || 0 : 0;
    const base64 = payloadText("p4x-rateios-payload");
    if (!base64) return;
    showStatus("Enviando os rateios para o portal...");
    ext.runtime.sendMessage({ action: "P4X_EXPORT_READY", base64, rows, pairs }).catch(() => {});
  });

  window.addEventListener("p4x-rateios-error", () => {
    const message = payloadText("p4x-rateios-error");
    ext.runtime.sendMessage({ action: "P4X_EXPORT_ERROR", message }).catch(() => {});
  });

  ext.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message) return;
    if (message.action === "PING") {
      sendResponse({ pong: true });
      return;
    }
    if (message.action === "EXPORTAR_RATEIOS") {
      inject("exporter.js", false);
      sendResponse({ started: true });
      return;
    }
    if (message.action === "RUN_EXPORT") {
      inject("exporter.js", true);
      sendResponse({ started: true });
      return;
    }
    if (message.action === "SHOW_STATUS") {
      showStatus(message.message);
      sendResponse({ ok: true });
    }
  });
})();
