(() => {
  if (window.__P4X_PORTAL_BRIDGE__) return;
  window.__P4X_PORTAL_BRIDGE__ = true;

  const ext = globalThis.browser || globalThis.chrome;
  const SESSION_KEY = "portal-session-v1";

  function dispatchResult(ok, message) {
    try {
      window.dispatchEvent(new CustomEvent("p4x-finance-result", {
        detail: JSON.stringify({ ok: Boolean(ok), message: String(message || "") })
      }));
    } catch (_) {}
  }

  // A página do portal pede a importação; a extensão confirma na hora e depois
  // devolve o resultado. Sem esta confirmação, a página avisa que a extensão não está instalada.
  window.addEventListener("p4x-finance-request", () => {
    try {
      window.dispatchEvent(new CustomEvent("p4x-finance-ack"));
    } catch (_) {}
    try {
      const pending = ext.runtime.sendMessage({ action: "P4X_FINANCE_EXPORT" });
      if (pending && pending.catch) pending.catch(() => {
        dispatchResult(false, "Não consegui falar com a extensão. Atualize a página e tente novamente.");
      });
    } catch (_) {
      dispatchResult(false, "Extensão indisponível. Instale ou atualize a extensão P4X - Exportar Rateios.");
    }
  });

  ext.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message) return;
    if (message.action === "GET_PORTAL_SESSION") {
      sendResponse({
        token: localStorage.getItem(SESSION_KEY) || "",
        origin: location.origin
      });
      return;
    }
    if (message.action === "FINANCE_RESULT") {
      dispatchResult(message.ok, message.message);
    }
  });
})();
