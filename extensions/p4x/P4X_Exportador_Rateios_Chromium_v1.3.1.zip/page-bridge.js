(() => {
  if (window.__P4X_RATEIOS_BRIDGE__) return;
  window.__P4X_RATEIOS_BRIDGE__ = true;

  function saveAuthorization(value, url) {
    try {
      if (!value || !/^Bearer\s+/i.test(value)) return;
      if (url && !String(url).includes("api.p4x.com.br")) return;
      window.__P4X_RATEIOS_AUTH__ = value.replace(/^Bearer\s+/i, "").trim();
    } catch (_) {}
  }

  // Reconhece a consulta da lista de rateios (e ignora a exportação em si).
  function parseListUrl(url) {
    try {
      if (!url) return null;
      const parsed = new URL(String(url), location.href);
      if (parsed.hostname !== "api.p4x.com.br") return null;
      if (parsed.pathname.replace(/\/+$/, "") !== "/extratos/rateios/recebidos") return null;
      if (parsed.searchParams.get("exportar") === "true") return null;
      return parsed;
    } catch (_) {
      return null;
    }
  }

  // Guarda a última consulta da lista: dela saem os filtros usados na
  // exportação (período, sacador, recebedor, etc.) e a forma de paginar.
  // Aceita GET (filtros na URL) e POST (filtros no corpo).
  function saveListRequest(parsed, request) {
    try {
      if (!parsed || window.__P4X_RATEIOS_INTERNAL__) return;
      window.__P4X_RATEIOS_LIST_URL__ = parsed.toString();
      window.__P4X_RATEIOS_LIST_REQUEST__ = {
        method: String(request.method || "GET").toUpperCase(),
        url: parsed.toString(),
        body: typeof request.body === "string" ? request.body : "",
        contentType: String(request.contentType || "")
      };
    } catch (_) {}
  }

  // Guarda também a resposta que a tela recebeu. Se refazer a consulta não
  // devolver os itens, o exportador usa exatamente o que o usuário está vendo.
  function saveListResponse(parsed, data) {
    try {
      if (!parsed || !data || window.__P4X_RATEIOS_INTERNAL__) return;
      window.__P4X_RATEIOS_LIST_RESPONSE__ = data;
      window.__P4X_RATEIOS_LIST_RESPONSE_URL__ = parsed.toString();
    } catch (_) {}
  }

  const originalFetch = window.fetch;
  window.fetch = function(input, init) {
    let parsedList = null;
    try {
      const url = typeof input === "string" ? input : (input && input.url) || "";
      const method = (init && init.method) || (input instanceof Request ? input.method : "") || "GET";
      let headers = null;
      try {
        headers = new Headers((init && init.headers) || (input instanceof Request ? input.headers : undefined));
      } catch (_) {}
      saveAuthorization(headers ? headers.get("authorization") : null, url);
      parsedList = parseListUrl(url);
      if (parsedList) {
        saveListRequest(parsedList, {
          method,
          body: init && typeof init.body === "string" ? init.body : "",
          contentType: headers ? (headers.get("content-type") || "") : ""
        });
      }
    } catch (_) {}
    const result = originalFetch.apply(this, arguments);
    if (parsedList) {
      try {
        result.then(response => {
          if (!response || !response.ok) return;
          response.clone().json()
            .then(data => saveListResponse(parsedList, data))
            .catch(() => {});
        }).catch(() => {});
      } catch (_) {}
    }
    return result;
  };

  function requestOf(xhr) {
    if (!xhr.__p4xRateiosRequest) {
      xhr.__p4xRateiosRequest = { method: "GET", url: "", body: "", contentType: "" };
    }
    return xhr.__p4xRateiosRequest;
  }

  const originalOpen = XMLHttpRequest.prototype.open;
  const originalSetRequestHeader = XMLHttpRequest.prototype.setRequestHeader;
  const originalSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function(method, url) {
    this.__p4xRateiosRequest = {
      method: String(method || "GET").toUpperCase(),
      url: String(url || ""),
      body: "",
      contentType: ""
    };
    return originalOpen.apply(this, arguments);
  };

  XMLHttpRequest.prototype.setRequestHeader = function(name, value) {
    const request = this.__p4xRateiosRequest;
    const header = String(name).toLowerCase();
    if (request) {
      if (header === "authorization") saveAuthorization(value, request.url);
      if (header === "content-type") request.contentType = String(value || "");
    }
    return originalSetRequestHeader.apply(this, arguments);
  };

  XMLHttpRequest.prototype.send = function(body) {
    const request = requestOf(this);
    if (typeof body === "string") request.body = body;
    const parsed = parseListUrl(request.url);
    if (parsed) {
      saveListRequest(parsed, request);
      this.addEventListener("load", () => {
        try {
          if (window.__P4X_RATEIOS_INTERNAL__) return;
          if (this.status < 200 || this.status >= 300) return;
          let data = null;
          if (this.responseType === "json") data = this.response;
          else if (this.responseType === "" || this.responseType === "text") data = JSON.parse(this.responseText);
          if (data) saveListResponse(parsed, data);
        } catch (_) {}
      });
    }
    return originalSend.apply(this, arguments);
  };
})();
