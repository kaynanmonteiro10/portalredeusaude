const ext = globalThis.browser || globalThis.chrome;

const P4X_URL = "https://portal.p4x.com.br/";
const P4X_PATTERN = "https://portal.p4x.com.br/*";
const PORTAL_PATTERNS = [
  "http://192.168.1.11/*",
  "https://192.168.1.11/*",
  "http://127.0.0.1/*",
  "https://127.0.0.1/*",
  "http://localhost/*",
  "https://localhost/*",
];
const PENDING_KEY = "p4xFinancePendingPortal";
const MAX_AUTO_UPLOAD = 26000000;

let pendingPortal = null;

function base64ToBytes(base64) {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index++) bytes[index] = binary.charCodeAt(index);
  return bytes;
}

function timestampName() {
  const now = new Date();
  const pad = value => String(value).padStart(2, "0");
  return `P4X_${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}_${pad(now.getHours())}${pad(now.getMinutes())}.xlsx`;
}

function pendingStore() {
  try {
    return ext.storage.session || ext.storage.local;
  } catch (_) {
    return null;
  }
}

async function setPendingPortal(portal) {
  pendingPortal = portal;
  const store = pendingStore();
  if (!store) return;
  try {
    await store.set({ [PENDING_KEY]: portal });
  } catch (_) {}
}

async function findPortalTab() {
  for (const pattern of PORTAL_PATTERNS) {
    let tabs = [];
    try {
      tabs = await ext.tabs.query({ url: pattern });
    } catch (_) {
      continue;
    }
    const tab = tabs.find(item => item.active) || tabs[0];
    if (tab && tab.id) return { tabId: tab.id };
  }
  return null;
}

async function takePendingPortal() {
  const memory = pendingPortal;
  pendingPortal = null;
  if (memory) return memory;
  const store = pendingStore();
  if (store) {
    try {
      const data = await store.get(PENDING_KEY);
      const stored = data && data[PENDING_KEY];
      if (stored) {
        await store.remove(PENDING_KEY);
        return stored;
      }
    } catch (_) {}
  }
  return findPortalTab();
}

async function report(portal, ok, message) {
  if (!portal) return;
  try {
    await ext.tabs.sendMessage(portal.tabId, { action: "FINANCE_RESULT", ok, message });
  } catch (_) {}
}

async function findP4xTab() {
  const tabs = await ext.tabs.query({ url: P4X_PATTERN });
  return tabs[0] || null;
}

async function waitForContentScript(tabId, attempts = 24) {
  for (let attempt = 0; attempt < attempts; attempt++) {
    try {
      const response = await ext.tabs.sendMessage(tabId, { action: "PING" });
      if (response && response.pong) return true;
    } catch (_) {}
    await new Promise(resolve => setTimeout(resolve, 250));
  }
  return false;
}

async function focusTab(tab) {
  try {
    await ext.tabs.update(tab.id, { active: true });
    if (tab.windowId) await ext.windows.update(tab.windowId, { focused: true });
  } catch (_) {}
}

async function startExport(portal) {
  let tab = await findP4xTab();
  if (!tab) {
    const created = await ext.tabs.create({ url: P4X_URL, active: true });
    await waitForContentScript(created.id);
    await report(
      portal,
      false,
      "Abri o P4X em outra aba. Entre, vá em Extratos → Rateios recebidos, aplique o filtro e clique em Pesquisar. Depois volte aqui e clique em Importar do P4X.",
    );
    return;
  }
  await focusTab(tab);
  if (!(await waitForContentScript(tab.id, 8))) {
    await report(portal, false, "Atualize a aba do P4X (F5) e clique em Importar do P4X novamente.");
    return;
  }
  try {
    await ext.tabs.sendMessage(tab.id, { action: "RUN_EXPORT" });
  } catch (_) {
    await report(portal, false, "Atualize a aba do P4X (F5) e clique em Importar do P4X novamente.");
  }
}

async function uploadToPortal(portal, message, sender) {
  if (!portal) return;
  if (!message.base64) {
    await report(portal, false, "A exportação não gerou dados para importar.");
    return;
  }
  if (message.base64.length > MAX_AUTO_UPLOAD) {
    await report(portal, false, "O arquivo ficou grande para envio automático. Use o ícone da extensão para baixar o Excel e clique em Enviar arquivo .xlsx.");
    return;
  }
  let session = null;
  try {
    session = await ext.tabs.sendMessage(portal.tabId, { action: "GET_PORTAL_SESSION" });
  } catch (_) {}
  if (!session || !session.token || !session.origin) {
    await report(portal, false, "A sessão do portal não foi encontrada. Atualize a página do portal, entre novamente e repita a importação.");
    return;
  }
  let response = null;
  let data = {};
  try {
    response = await fetch(
      `${session.origin}/api/finance/rateios/import?force=1&name=${encodeURIComponent(timestampName())}`,
      {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${session.token}`,
          "Content-Type": "application/octet-stream",
        },
        body: base64ToBytes(message.base64),
      },
    );
    data = await response.json().catch(() => ({}));
  } catch (_) {
    await report(portal, false, "Não consegui enviar ao portal. Confirme que o portal está aberto e acessível e tente novamente.");
    return;
  }
  if (response.status === 401) {
    await report(portal, false, "A sessão do portal expirou. Atualize a página, entre novamente e repita a importação.");
    return;
  }
  if (!response.ok) {
    await report(portal, false, data.error || "O portal recusou a importação do consolidado.");
    return;
  }
  const imported = data.import || {};
  const total = `${imported.rows || 0} lançamentos importados de ${imported.files || 0} arquivo(s)${data.replaced ? " · importação anterior substituída" : ""}.`;
  await report(portal, true, total);
  if (sender && sender.tab && sender.tab.id) {
    try {
      await ext.tabs.sendMessage(sender.tab.id, { action: "SHOW_STATUS", message: total });
    } catch (_) {}
  }
  try {
    const portalTab = await ext.tabs.get(portal.tabId);
    await focusTab(portalTab);
  } catch (_) {}
}

ext.runtime.onMessage.addListener((message, sender) => {
  if (!message) return;

  if (message.action === "P4X_FINANCE_EXPORT") {
    if (!sender.tab || !sender.tab.id) return;
    const portal = { tabId: sender.tab.id };
    setPendingPortal(portal).then(() => startExport(portal));
    return;
  }

  if (message.action === "P4X_EXPORT_READY") {
    const senderUrl = String((sender && sender.url) || (sender && sender.tab && sender.tab.url) || "");
    if (!senderUrl.startsWith(P4X_URL)) return;
    takePendingPortal().then(portal => portal && uploadToPortal(portal, message, sender));
    return;
  }

  if (message.action === "P4X_EXPORT_ERROR") {
    takePendingPortal().then(portal => {
      if (portal) report(portal, false, message.message || "A exportação falhou no P4X.");
    });
  }
});
